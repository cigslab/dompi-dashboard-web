"""Stable, transport-neutral errors. Never serialize provider exception details."""
from enum import Enum
from types import MappingProxyType


class ErrorCode(str, Enum):
    ENTITLEMENT_REVIEW_REQUIRED = 'entitlement_review_required'
    FEATURE_NOT_ALLOWED = 'feature_not_allowed'
    INSUFFICIENT_CREDIT = 'insufficient_credit'
    OPERATION_IN_PROGRESS = 'operation_in_progress'
    IDEMPOTENCY_CONFLICT = 'idempotency_conflict'
    EXECUTION_UNCERTAIN = 'execution_uncertain'
    TEMPORARILY_UNAVAILABLE = 'temporarily_unavailable'
    UNKNOWN_FEATURE = 'unknown_feature'
    POLICY_NOT_FOUND = 'policy_not_found'
    POLICY_MISSING = 'policy_missing'
    LEGACY_POLICY_REQUIRED = 'legacy_policy_required'


class RetryAction(str, Enum):
    NONE = 'none'
    CHECK_STATUS = 'check_status'
    SAME_OPERATION = 'same_operation'


_RETRY = MappingProxyType({
    code: (RetryAction.CHECK_STATUS if code in (
        ErrorCode.OPERATION_IN_PROGRESS, ErrorCode.EXECUTION_UNCERTAIN
    ) else RetryAction.SAME_OPERATION if code == ErrorCode.TEMPORARILY_UNAVAILABLE
    else RetryAction.NONE)
    for code in ErrorCode
})


class CoreError(Exception):
    """Only a stable code and an optional opaque operation ID cross adapters.

    SAME_OPERATION means reusing the idempotency key, never blindly retrying AI.
    Validation/programming errors use ValueError and are not client responses.
    """
    def __init__(self, code: ErrorCode, *, operation_id: str | None = None):
        if not isinstance(code, ErrorCode):
            raise ValueError('Explicit ErrorCode required')
        if operation_id is not None and (
            not isinstance(operation_id, str) or not operation_id or
            len(operation_id) > 128 or
            any(c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_' for c in operation_id)
        ):
            raise ValueError('operation_id must be an opaque identifier')
        self.code = code
        self.operation_id = operation_id
        super().__init__(code.value)

    @property
    def retry_action(self):
        return _RETRY[self.code]

    def to_dict(self):
        return {'code': self.code.value, 'operation_id': self.operation_id,
                'retry_action': self.retry_action.value}
