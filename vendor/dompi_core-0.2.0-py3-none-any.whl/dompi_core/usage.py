"""Usage contracts. No connections, clock reads, provider calls or imports on startup."""
from dataclasses import dataclass
from datetime import datetime, timezone
import json
import re


def identifier(value, name):
    if not isinstance(value, str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,128}', value):
        raise ValueError(f'{name} must be an opaque identifier (1..128 characters)')
    return value


def aware(value):
    if not isinstance(value, datetime) or value.tzinfo is None or value.utcoffset() is None:
        raise ValueError('Timezone-aware datetime required')
    return value


def monthly_period(now, timezone_name='Asia/Jakarta'):
    # zoneinfo imports read interpreter environment on some Python versions;
    # defer until an explicit runtime calculation, never package import.
    from zoneinfo import ZoneInfo
    local = aware(now).astimezone(ZoneInfo(timezone_name))
    start = local.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    end = start.replace(year=start.year + 1, month=1) if start.month == 12 else start.replace(month=start.month + 1)
    return start.astimezone(timezone.utc), end.astimezone(timezone.utc)


def json_document(value):
    """Bounded, detached JSON object. Callers must sanitize feature-specific data."""
    if not isinstance(value, dict):
        raise ValueError('JSON object required')
    encoded = json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)
    if len(encoded.encode()) > 65536:
        raise ValueError('Result exceeds 64 KiB')
    return encoded


@dataclass(frozen=True)
class UsageRequest:
    feature: str
    fingerprint: str

    def __post_init__(self):
        identifier(self.feature, 'feature')
        if not isinstance(self.fingerprint, str) or not re.fullmatch('[a-f0-9]{64}', self.fingerprint):
            raise ValueError('SHA-256 request fingerprint required')


@dataclass(frozen=True)
class Operation:
    id: str
    identity_id: str
    feature: str
    state: str
    funding: str
    credits: int
    policy_version: str
    result: dict | None
    reason: str | None


@dataclass(frozen=True)
class ExecutionClaim:
    operation: Operation
    token: str | None


@dataclass(frozen=True)
class ExecutionResult:
    """Trusted adapter evidence, never accepted directly from an end-user request.

    valid means the complete feature pipeline passed its validator. Local-only
    or invalid results release their hold instead of becoming a charge.
    """
    ai_executed: bool
    valid: bool
    payload: dict

    def __post_init__(self):
        if type(self.ai_executed) is not bool or type(self.valid) is not bool:
            raise ValueError('Explicit execution and validation booleans required')
        json_document(self.payload)


@dataclass(frozen=True)
class VerifiedTopUp:
    """Internal ledger input from a trusted verifier; NOT webhook verification.

    source_key must identify the economic provider transaction, not a delivery
    event. Adapters must verify signature, ownership, order and final status.
    No adapter is wired in slice 2.
    """
    source_key: str
    order_id: str
    policy_version: str
    product_code: str
    paid_idr: int
    verification_reference: str

    def __post_init__(self):
        for name in ('source_key', 'order_id', 'verification_reference'):
            identifier(getattr(self, name), name)
        if type(self.paid_idr) is not int or self.paid_idr <= 0:
            raise ValueError('Positive integer IDR required')
