"""Shared Dompi business contracts. Importing this package has no runtime side effects."""
from .entitlements import (CONTRACT_VERSION, Entitlement, Capabilities,
                           resolve_entitlement, resolve_capabilities, has_paid_access)

__version__ = '0.2.0'
