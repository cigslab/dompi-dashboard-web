"""PostgreSQL usage ledger. Inject a connection factory; never read a DSN.

All public mutations own a SHORT transaction. No provider/network callbacks.
Lock order: account -> wallet -> identity -> contracts -> batch/buckets/operations.
Every writer serializes on the account row, including both linked identities.
Only DB deadlock/serialization failures are retried, never external AI execution.
"""
from dataclasses import asdict
from datetime import timedelta
from contextlib import closing
import hashlib
import json
from uuid import uuid4

from ..errors import CoreError, ErrorCode
from ..policies import get_policy
from ..usage import (ExecutionClaim, ExecutionResult, Operation, UsageRequest,
                     VerifiedTopUp, aware, identifier, json_document, monthly_period)


def _row(c):
    row = c.fetchone()
    return dict(zip((d[0] for d in c.description), row)) if row is not None else None


def _view(row):
    return Operation(**{name: row[name] for name in Operation.__dataclass_fields__})


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()


class PostgresUsage:
    def __init__(self, connect, *, clock=None, reserve_ttl=timedelta(minutes=5),
                 execute_ttl=timedelta(minutes=2), recovery_grace=timedelta(minutes=5)):
        if not callable(connect) or (clock is not None and not callable(clock)):
            raise ValueError('Explicit connection factory and optional clock required')
        for ttl in (reserve_ttl, execute_ttl, recovery_grace):
            if not isinstance(ttl, timedelta) or ttl <= timedelta(0):
                raise ValueError('Positive duration required')
        self.connect, self.clock = connect, clock
        self.reserve_ttl, self.execute_ttl, self.recovery_grace = reserve_ttl, execute_ttl, recovery_grace

    def _now(self, c):
        if self.clock is not None:
            return aware(self.clock())
        c.execute('SELECT clock_timestamp()')
        return c.fetchone()[0]

    def _actor(self, c, identity_id):
        c.execute('SELECT account_id FROM core_identities WHERE id=%s', (identity_id,))
        found = c.fetchone()
        if found is None:
            raise CoreError(ErrorCode.FEATURE_NOT_ALLOWED)
        account = found[0]
        c.execute('SELECT id FROM core_accounts WHERE id=%s FOR UPDATE', (account,))
        c.execute('SELECT account_id FROM core_wallets WHERE account_id=%s FOR UPDATE', (account,))
        if c.fetchone() is None:
            raise CoreError(ErrorCode.TEMPORARILY_UNAVAILABLE)
        c.execute('SELECT * FROM core_identities WHERE id=%s FOR UPDATE', (identity_id,))
        actor = _row(c)
        if actor is None or actor['account_id'] != account:
            # Linking locks accounts in sorted order. Stale routing must retry;
            # never write against the wallet observed before a concurrent link.
            raise CoreError(ErrorCode.TEMPORARILY_UNAVAILABLE)
        return actor

    def _run(self, identity_id, action):
        identifier(identity_id, 'identity_id')
        for attempt in range(3):
            with closing(self.connect()) as conn:
                try:
                    conn.set_session(isolation_level='READ COMMITTED', autocommit=False)
                    with conn.cursor() as c:
                        actor = self._actor(c, identity_id)
                        value = action(c, actor, self._now(c))
                    conn.commit()
                    return value
                except BaseException as error:
                    conn.rollback()
                    code = getattr(error, 'pgcode', None)
                    if code in ('40001', '40P01') and attempt < 2:
                        continue
                    if code == '23505':
                        raise CoreError(ErrorCode.IDEMPOTENCY_CONFLICT) from None
                    if code in ('40001', '40P01', '55P03', '57014'):
                        raise CoreError(ErrorCode.TEMPORARILY_UNAVAILABLE) from None
                    raise

    def _contract(self, c, actor, now):
        c.execute('''SELECT * FROM core_channel_contracts WHERE identity_id=%s
                     AND starts_at <= %s AND (ends_at IS NULL OR ends_at > %s) FOR UPDATE''',
                  (actor['id'], now, now))
        first = _row(c)
        if first is None or c.fetchone() is not None:
            raise CoreError(ErrorCode.ENTITLEMENT_REVIEW_REQUIRED)
        if first['cohort'] == 'legacy':
            raise CoreError(ErrorCode.LEGACY_POLICY_REQUIRED)
        if first['requires_review']:
            raise CoreError(ErrorCode.ENTITLEMENT_REVIEW_REQUIRED)
        policy = get_policy(version=first['policy_version'], cohort=first['cohort'])
        c.execute('SELECT content_hash, snapshot FROM core_policies WHERE version=%s', (policy.version,))
        if c.fetchone() != (policy.content_hash, policy.snapshot()):
            raise CoreError(ErrorCode.POLICY_NOT_FOUND)
        return first, policy

    def _operation(self, c, actor, operation_id):
        identifier(operation_id, 'operation_id')
        c.execute('SELECT * FROM core_usage_operations WHERE id=%s AND identity_id=%s FOR UPDATE',
                  (operation_id, actor['id']))
        row = _row(c)
        if row is None or (row['account_id'] != actor['account_id'] and
                (row['state'] not in ('committed','released','reversed') or
                 not self._same_wallet(c,row['account_id'],actor['account_id']))):
            raise CoreError(ErrorCode.FEATURE_NOT_ALLOWED)
        return row

    @staticmethod
    def _wallet_accounts(c,account):
        # Additive linking schema is optional for existing flag-OFF deployments.
        c.execute("SELECT to_regclass('core_wallet_merges')")
        if c.fetchone()[0] is None: return [account]
        c.execute('SELECT source_account FROM core_wallet_merges WHERE target_account=%s',(account,))
        return [account]+[r[0] for r in c.fetchall()]

    @classmethod
    def _same_wallet(cls,c,old,current):
        return old==current or old in cls._wallet_accounts(c,current)

    @staticmethod
    def _requests(requests):
        requests = tuple(requests)
        if not requests or any(not isinstance(r, UsageRequest) for r in requests):
            raise ValueError('Nonempty UsageRequest batch required')
        return requests

    def quote(self, identity_id, requests):
        """Read-only estimate, never a reservation or authorization to execute."""
        requests = self._requests(requests)
        def action(c, actor, now):
            contract, policy = self._contract(c, actor, now)
            start, _ = monthly_period(now, policy.period_timezone)
            remaining, quota_units, credit_units, credits = {}, 0, 0, 0
            for request in requests:
                terms = policy.terms(channel=actor['channel'], plan=contract['plan'], feature=request.feature)
                if not policy.features.get(request.feature).uses_ai:
                    raise CoreError(ErrorCode.FEATURE_NOT_ALLOWED)
                if request.feature not in remaining:
                    c.execute('''SELECT committed+reserved FROM core_quota_buckets
                                 WHERE identity_id=%s AND feature=%s AND period_start=%s''',
                              (identity_id, request.feature, start))
                    used = c.fetchone()
                    remaining[request.feature] = max(0, terms.included_units - (used[0] if used else 0))
                if remaining[request.feature]:
                    remaining[request.feature] -= 1
                    quota_units += 1
                else:
                    credit_units += 1
                    credits += terms.credits_per_unit
            c.execute('SELECT balance-reserved FROM core_wallets WHERE account_id=%s', (actor['account_id'],))
            available = c.fetchone()[0]
            return {'policy_version': policy.version, 'quota_units': quota_units,
                    'credit_units': credit_units, 'credits_required': credits,
                    'available_credits': available, 'affordable': credits <= available}
        return self._run(identity_id, action)

    def reserve(self, identity_id, event_key, requests):
        """Atomically reserve an entire batch. One request = one AI business unit.

        Event key and child order MUST be stable across retries. Manual/local-only
        work is omitted by the adapter. Same key with changed payload is rejected.
        """
        identifier(event_key, 'event_key')
        requests = self._requests(requests)
        fingerprint = _digest([asdict(r) for r in requests])

        def action(c, actor, now):
            c.execute('SELECT * FROM core_usage_batches WHERE identity_id=%s AND event_key=%s',
                      (identity_id, event_key))
            prior = _row(c)
            if prior is not None:
                if prior['request_fingerprint'] != fingerprint:
                    raise CoreError(ErrorCode.IDEMPOTENCY_CONFLICT)
                c.execute('SELECT * FROM core_usage_operations WHERE batch_id=%s ORDER BY child_index', (prior['id'],))
                return tuple(_view(_row(c)) for _ in requests)
            contract, policy = self._contract(c, actor, now)
            start, end = monthly_period(now, policy.period_timezone)
            batch_id = uuid4().hex
            c.execute('INSERT INTO core_usage_batches VALUES (%s,%s,%s,%s)',
                      (batch_id, identity_id, event_key, fingerprint))
            operations = []
            for index, request in enumerate(requests):
                terms = policy.terms(channel=actor['channel'], plan=contract['plan'], feature=request.feature)
                if not policy.features.get(request.feature).uses_ai:
                    raise CoreError(ErrorCode.FEATURE_NOT_ALLOWED)
                c.execute('''INSERT INTO core_quota_buckets(identity_id,feature,period_start,period_end)
                             VALUES (%s,%s,%s,%s) ON CONFLICT DO NOTHING''',
                          (identity_id, request.feature, start, end))
                c.execute('''SELECT * FROM core_quota_buckets WHERE identity_id=%s AND feature=%s
                             AND period_start=%s FOR UPDATE''', (identity_id, request.feature, start))
                bucket = _row(c)
                quota = bucket['committed'] + bucket['reserved'] < terms.included_units
                credits = 0 if quota else terms.credits_per_unit
                if quota:
                    c.execute('UPDATE core_quota_buckets SET reserved=reserved+1 WHERE id=%s', (bucket['id'],))
                else:
                    c.execute('''UPDATE core_wallets SET reserved=reserved+%s WHERE account_id=%s
                                 AND balance-reserved >= %s''', (credits, actor['account_id'], credits))
                    if c.rowcount != 1:
                        raise CoreError(ErrorCode.INSUFFICIENT_CREDIT)
                operation_id = uuid4().hex
                c.execute('''INSERT INTO core_usage_operations
                    (id,batch_id,child_index,identity_id,account_id,feature,request_fingerprint,
                     policy_version,policy_snapshot,bucket_id,funding,credits,state,reserve_until,created_at)
                    VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s::jsonb,%s,%s,%s,'reserved',%s,%s) RETURNING *''',
                          (operation_id, batch_id, index, identity_id, actor['account_id'], request.feature,
                           request.fingerprint, policy.version, json.dumps(policy.snapshot()), bucket['id'],
                           'quota' if quota else 'credit', credits, now + self.reserve_ttl, now))
                operations.append(_view(_row(c)))
            return tuple(operations)
        return self._run(identity_id, action)

    def get(self, identity_id, operation_id):
        return self._run(identity_id, lambda c, a, n: _view(self._operation(c, a, operation_id)))

    def balance(self, identity_id):
        def action(c, actor, now):
            c.execute('SELECT balance,reserved,balance-reserved AS available FROM core_wallets WHERE account_id=%s',
                      (actor['account_id'],))
            return _row(c)
        return self._run(identity_id, action)

    def _release(self, c, row, now, reason):
        if row['state'] in ('released', 'committed', 'reversed'):
            return _view(row)
        if row['funding'] == 'quota':
            c.execute('UPDATE core_quota_buckets SET reserved=reserved-1 WHERE id=%s', (row['bucket_id'],))
        else:
            c.execute('UPDATE core_wallets SET reserved=reserved-%s WHERE account_id=%s', (row['credits'], row['account_id']))
        c.execute("UPDATE core_usage_operations SET state='released',reason=%s,settled_at=%s WHERE id=%s RETURNING *",
                  (reason, now, row['id']))
        return _view(_row(c))

    def start_execution(self, identity_id, operation_id):
        def action(c, actor, now):
            row = self._operation(c, actor, operation_id)
            if row['state'] in ('executing', 'uncertain'):
                code = ErrorCode.EXECUTION_UNCERTAIN if row['state'] == 'uncertain' else ErrorCode.OPERATION_IN_PROGRESS
                raise CoreError(code, operation_id=operation_id)
            if row['state'] != 'reserved':
                return ExecutionClaim(_view(row), None)
            if now >= row['reserve_until']:
                return ExecutionClaim(self._release(c, row, now, 'reservation_expired'), None)
            token = uuid4().hex
            c.execute('''UPDATE core_usage_operations SET state='executing',execution_token=%s,
                         execute_until=%s,recover_after=%s WHERE id=%s RETURNING *''',
                      (token, now + self.execute_ttl, now + self.execute_ttl + self.recovery_grace, operation_id))
            return ExecutionClaim(_view(_row(c)), token)
        return self._run(identity_id, action)

    def mark_uncertain(self, identity_id, operation_id, token):
        def action(c, actor, now):
            row = self._operation(c, actor, operation_id)
            self._token(row, token)
            if row['state'] == 'executing':
                c.execute("UPDATE core_usage_operations SET state='uncertain' WHERE id=%s RETURNING *", (operation_id,))
                row = _row(c)
            return _view(row)
        return self._run(identity_id, action)

    @staticmethod
    def _token(row, token):
        if not token or row['execution_token'] != token:
            raise CoreError(ErrorCode.IDEMPOTENCY_CONFLICT, operation_id=row['id'])

    def release(self, identity_id, operation_id, *, reason, token=None):
        identifier(reason, 'reason')
        def action(c, actor, now):
            row = self._operation(c, actor, operation_id)
            if row['state'] in ('executing', 'uncertain'):
                self._token(row, token)
            return self._release(c, row, now, reason)
        return self._run(identity_id, action)

    def complete(self, identity_id, operation_id, token, result):
        if not isinstance(result, ExecutionResult):
            raise ValueError('Trusted ExecutionResult required')
        # Detach before starting a transaction: no caller-owned mutable payload.
        payload = json_document(result.payload)
        fingerprint = _digest({'ai_executed': result.ai_executed, 'valid': result.valid,
                               'payload': json.loads(payload)})
        def action(c, actor, now):
            row = self._operation(c, actor, operation_id)
            self._token(row, token)
            if row['state'] in ('committed', 'reversed'):
                if row['result_fingerprint'] != fingerprint:
                    raise CoreError(ErrorCode.IDEMPOTENCY_CONFLICT, operation_id=operation_id)
                return _view(row)
            if row['state'] == 'released':
                return _view(row)  # Late worker cannot resurrect a refunded unit.
            if row['state'] not in ('executing', 'uncertain'):
                raise CoreError(ErrorCode.IDEMPOTENCY_CONFLICT, operation_id=operation_id)
            if now >= row['recover_after']:
                return self._release(c, row, now, 'execution_expired')
            if not result.ai_executed or not result.valid:
                return self._release(c, row, now, 'ai_failed' if result.ai_executed else 'no_ai_execution')
            if row['funding'] == 'quota':
                c.execute('UPDATE core_quota_buckets SET reserved=reserved-1,committed=committed+1 WHERE id=%s',
                          (row['bucket_id'],))
            else:
                c.execute('UPDATE core_wallets SET reserved=reserved-%s,balance=balance-%s WHERE account_id=%s',
                          (row['credits'], row['credits'], row['account_id']))
                c.execute('''INSERT INTO core_credit_entries(account_id,kind,amount,operation_id,metadata,created_at)
                             VALUES (%s,'debit',%s,%s,%s::jsonb,%s)''',
                          (row['account_id'], -row['credits'], operation_id,
                           json.dumps({'policy_version': row['policy_version']}), now))
            c.execute('''UPDATE core_usage_operations SET state='committed',result=%s::jsonb,
                         result_fingerprint=%s,settled_at=%s WHERE id=%s RETURNING *''',
                      (payload, fingerprint, now, operation_id))
            return _view(_row(c))
        return self._run(identity_id, action)

    def reverse(self, identity_id, operation_id, *, reason, authorized_reference):
        """Internal correction only. Ordinary user cancellation uses release.

        The caller must authorize this administrative action before invocation.
        There is deliberately no application/API endpoint in this slice.
        """
        identifier(reason, 'reason')
        identifier(authorized_reference, 'authorized_reference')
        def action(c, actor, now):
            row = self._operation(c, actor, operation_id)
            if row['state'] == 'reversed':
                return _view(row)
            if row['state'] != 'committed':
                raise CoreError(ErrorCode.IDEMPOTENCY_CONFLICT, operation_id=operation_id)
            if row['funding'] == 'quota':
                c.execute('UPDATE core_quota_buckets SET committed=committed-1 WHERE id=%s', (row['bucket_id'],))
            else:
                c.execute('UPDATE core_wallets SET balance=balance+%s WHERE account_id=%s', (row['credits'], actor['account_id']))
                c.execute('''INSERT INTO core_credit_entries(account_id,kind,amount,operation_id,metadata,created_at)
                             VALUES (%s,'refund',%s,%s,%s::jsonb,%s)''',
                          (actor['account_id'], row['credits'], operation_id,
                           json.dumps({'reason': reason, 'authorized_reference': authorized_reference}), now))
            c.execute("UPDATE core_usage_operations SET state='reversed',reason=%s WHERE id=%s RETURNING *",
                      (reason + ':' + authorized_reference, operation_id))
            return _view(_row(c))
        return self._run(identity_id, action)

    def credit_topup(self, identity_id, receipt):
        """Trusted verified receipt only; provider verification is NOT implemented."""
        if not isinstance(receipt, VerifiedTopUp):
            raise ValueError('VerifiedTopUp required')
        policy = get_policy(version=receipt.policy_version, cohort='v2_purchase')
        topup = policy.topup(receipt.product_code)
        if receipt.paid_idr != topup.price_idr:
            raise CoreError(ErrorCode.IDEMPOTENCY_CONFLICT)
        return self._run(identity_id, lambda c, actor, now:
                         self._credit_topup(c, actor, now, receipt))

    def _credit_topup(self, c, actor, now, receipt):
        """Same transaction primitive for verified order settlement (Slice 4)."""
        policy = get_policy(version=receipt.policy_version, cohort='v2_purchase')
        topup = policy.topup(receipt.product_code)
        if receipt.paid_idr != topup.price_idr:
            raise CoreError(ErrorCode.IDEMPOTENCY_CONFLICT)
        metadata = asdict(receipt)
        metadata['identity_id'] = actor['id']
        c.execute('SELECT * FROM core_credit_entries WHERE source_key=%s OR order_id=%s',
                  (receipt.source_key, receipt.order_id))
        previous = _row(c)
        if previous:
            extra=c.fetchone()
            if (extra is not None or not self._same_wallet(c,previous['account_id'],actor['account_id']) or
                    previous['amount'] != topup.credits or
                    any(previous['metadata'].get(k) != v for k, v in metadata.items() if k != 'verification_reference')):
                raise CoreError(ErrorCode.IDEMPOTENCY_CONFLICT)
            return previous['id']
        # No top-up on unprovisioned/legacy contracts in this rollout slice.
        self._contract(c, actor, now)
        c.execute('''INSERT INTO core_credit_entries(account_id,kind,amount,source_key,order_id,metadata,created_at)
                     VALUES (%s,'topup',%s,%s,%s,%s::jsonb,%s) RETURNING id''',
                  (actor['account_id'], topup.credits, receipt.source_key, receipt.order_id, json.dumps(metadata), now))
        entry = c.fetchone()[0]
        c.execute('UPDATE core_wallets SET balance=balance+%s WHERE account_id=%s', (topup.credits, actor['account_id']))
        return entry

    def recover(self, *, limit=100):
        """Bounded sweep; safe to run concurrently. No provider retry or network.

        Per-operation lock/recheck prevents a stale selection releasing a result
        committed by another worker. No long-lived/global recovery lock.
        """
        if type(limit) is not int or not 1 <= limit <= 1000:
            raise ValueError('Recovery limit must be 1..1000')
        with closing(self.connect()) as conn:
            with conn.cursor() as c:
                now = self._now(c)
                c.execute('''SELECT identity_id,id FROM core_usage_operations WHERE
                    (state='reserved' AND reserve_until<=%s) OR
                    (state='executing' AND execute_until<=%s) OR
                    (state='uncertain' AND recover_after<=%s)
                    ORDER BY created_at,id LIMIT %s''', (now, now, now, limit))
                pending = c.fetchall()
            conn.rollback()
        results = []
        for identity_id, operation_id in pending:
            def action(c, actor, current):
                row = self._operation(c, actor, operation_id)
                if row['state'] == 'reserved' and current >= row['reserve_until']:
                    return self._release(c, row, current, 'reservation_expired')
                if row['state'] in ('executing', 'uncertain'):
                    if current >= row['recover_after']:
                        return self._release(c, row, current, 'execution_expired')
                    if row['state'] == 'executing' and current >= row['execute_until']:
                        c.execute("UPDATE core_usage_operations SET state='uncertain' WHERE id=%s RETURNING *", (operation_id,))
                        return _view(_row(c))
                return _view(row)
            results.append(self._run(identity_id, action))
        return tuple(results)
