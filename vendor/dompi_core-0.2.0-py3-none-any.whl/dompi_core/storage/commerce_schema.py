"""Additive top-up order snapshots. Explicit caller-owned migration only."""
import hashlib

VERSION = 'core_commerce_v2_001'
DDL = '''
CREATE TABLE core_topup_orders (
 id TEXT PRIMARY KEY, identity_id TEXT NOT NULL REFERENCES core_identities(id),
 account_id TEXT NOT NULL REFERENCES core_wallets(account_id),
 request_key TEXT NOT NULL, product_code TEXT NOT NULL,
 policy_version TEXT NOT NULL REFERENCES core_policies(version),
 price_idr BIGINT NOT NULL CHECK (price_idr > 0),
 credits BIGINT NOT NULL CHECK (credits > 0),
 provider TEXT NOT NULL CHECK (provider='lynk'), product_reference TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','paid')),
 ledger_id BIGINT UNIQUE REFERENCES core_credit_entries(id),
 created_at TIMESTAMPTZ NOT NULL, paid_at TIMESTAMPTZ,
 UNIQUE(identity_id,request_key),
 CHECK ((status='pending' AND ledger_id IS NULL AND paid_at IS NULL) OR
        (status='paid' AND ledger_id IS NOT NULL AND paid_at IS NOT NULL)));
CREATE INDEX core_topup_owner_history ON core_topup_orders(identity_id,created_at,id);
CREATE FUNCTION core_order_snapshot_guard() RETURNS trigger LANGUAGE plpgsql AS $$
 BEGIN
 IF (to_jsonb(NEW) - ARRAY['status','ledger_id','paid_at']) IS DISTINCT FROM
    (to_jsonb(OLD) - ARRAY['status','ledger_id','paid_at']) OR OLD.status='paid' THEN
   RAISE EXCEPTION 'Immutable top-up snapshot';
 END IF;
 RETURN NEW;
 END $$;
CREATE TRIGGER core_order_snapshot_immutable BEFORE UPDATE ON core_topup_orders
 FOR EACH ROW EXECUTE FUNCTION core_order_snapshot_guard();
CREATE TRIGGER core_order_no_delete BEFORE DELETE ON core_topup_orders
 FOR EACH ROW EXECUTE FUNCTION core_reject_mutation();
CREATE TRIGGER core_order_no_truncate BEFORE TRUNCATE ON core_topup_orders
 FOR EACH STATEMENT EXECUTE FUNCTION core_reject_mutation();
'''


def migrate(connection):
    if connection.autocommit:
        raise ValueError('Caller-owned migration transaction required')
    with connection.cursor() as c:
        c.execute('SAVEPOINT core_commerce_migration')
        try:
            c.execute('SELECT pg_advisory_xact_lock(193003,2)')
            c.execute('SELECT ddl_hash FROM core_migrations WHERE version=%s', (VERSION,))
            old = c.fetchone()
            digest = hashlib.sha256(DDL.encode()).hexdigest()
            if old and old[0] != digest:
                raise ValueError('Commerce migration fingerprint mismatch')
            if not old:
                c.execute(DDL)
                c.execute('INSERT INTO core_migrations VALUES (%s,%s)', (VERSION,digest))
            c.execute('RELEASE SAVEPOINT core_commerce_migration')
            return old is None
        except BaseException:
            c.execute('ROLLBACK TO SAVEPOINT core_commerce_migration')
            c.execute('RELEASE SAVEPOINT core_commerce_migration')
            raise
