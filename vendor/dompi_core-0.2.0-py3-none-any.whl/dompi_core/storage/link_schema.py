"""Explicit additive linking migration; no entitlement changes or backfill."""
import hashlib

VERSION='core_linking_v2_001'
DDL='''
CREATE TABLE core_link_requests (
 id TEXT PRIMARY KEY, token_hash TEXT UNIQUE NOT NULL,
 telegram_identity TEXT NOT NULL REFERENCES core_identities(id),
 whatsapp_identity TEXT REFERENCES core_identities(id),
 state TEXT NOT NULL CHECK(state IN ('pending','claimed','linked','cancelled')),
 created_at TIMESTAMPTZ NOT NULL, expires_at TIMESTAMPTZ NOT NULL,
 CHECK(expires_at>created_at));
CREATE TABLE core_link_attempts (
 identity_id TEXT NOT NULL REFERENCES core_identities(id), created_at TIMESTAMPTZ NOT NULL);
CREATE INDEX core_link_attempt_window ON core_link_attempts(identity_id,created_at);
CREATE TABLE core_wallet_merges (
 source_account TEXT PRIMARY KEY REFERENCES core_wallets(account_id),
 target_account TEXT UNIQUE NOT NULL REFERENCES core_wallets(account_id),
 request_id TEXT UNIQUE NOT NULL REFERENCES core_link_requests(id),
 telegram_identity TEXT UNIQUE NOT NULL REFERENCES core_identities(id),
 whatsapp_identity TEXT UNIQUE NOT NULL REFERENCES core_identities(id),
 amount BIGINT NOT NULL CHECK(amount>=0), created_at TIMESTAMPTZ NOT NULL,
 CHECK(source_account<>target_account));
CREATE TRIGGER core_merge_immutable BEFORE UPDATE OR DELETE ON core_wallet_merges
 FOR EACH ROW EXECUTE FUNCTION core_reject_mutation();
CREATE TRIGGER core_merge_no_truncate BEFORE TRUNCATE ON core_wallet_merges
 FOR EACH STATEMENT EXECUTE FUNCTION core_reject_mutation();
'''


def migrate(connection):
    if connection.autocommit: raise ValueError('Caller-owned transaction required')
    with connection.cursor() as c:
        c.execute('SAVEPOINT core_linking_migration')
        try:
            c.execute('SELECT pg_advisory_xact_lock(193003,2)')
            c.execute('SELECT ddl_hash FROM core_migrations WHERE version=%s',(VERSION,))
            old=c.fetchone();digest=hashlib.sha256(DDL.encode()).hexdigest()
            if old and old[0]!=digest: raise ValueError('Linking migration fingerprint mismatch')
            if not old:
                c.execute(DDL);c.execute('INSERT INTO core_migrations VALUES(%s,%s)',(VERSION,digest))
            c.execute('RELEASE SAVEPOINT core_linking_migration')
            return old is None
        except BaseException:
            c.execute('ROLLBACK TO SAVEPOINT core_linking_migration');c.execute('RELEASE SAVEPOINT core_linking_migration');raise
