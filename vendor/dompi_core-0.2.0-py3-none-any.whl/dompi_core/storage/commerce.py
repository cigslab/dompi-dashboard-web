"""Dashboard projections and atomic top-up fulfillment. No checkout/network I/O."""
from contextlib import closing
import hashlib
from uuid import uuid4
from .postgres import PostgresUsage, _row
from ..commerce import PaymentError, VerifiedPayment
from ..errors import CoreError, ErrorCode
from ..usage import VerifiedTopUp, identifier, monthly_period


def public_order(value):
    return {k: (v.isoformat() if hasattr(v,'isoformat') else v)
            for k,v in value.items() if k in (
                'id','product_code','policy_version','price_idr','credits','status','created_at','paid_at')}


class PostgresCommerce(PostgresUsage):
    def identity(self, telegram_id):
        if type(telegram_id) is not int or telegram_id <= 0:
            raise ValueError('Authenticated Telegram ID required')
        with closing(self.connect()) as conn:
            with conn.cursor() as c:
                c.execute("SELECT id FROM core_identities WHERE channel='telegram' AND external_subject=%s",(str(telegram_id),))
                result = c.fetchone()
                return result[0] if result else None

    def overview(self, identity_id):
        def action(c, actor, now):
            contract, policy = self._contract(c, actor, now)
            start,end = monthly_period(now,policy.period_timezone)
            c.execute('SELECT balance,reserved FROM core_wallets WHERE account_id=%s',(actor['account_id'],))
            balance,held = c.fetchone()
            quotas=[]
            for feature,terms in policy.package(channel=actor['channel'],plan=contract['plan']).usage.items():
                if terms.included_units is None: continue
                c.execute('SELECT committed,reserved FROM core_quota_buckets WHERE identity_id=%s AND feature=%s AND period_start=%s',
                          (actor['id'],feature,start))
                used,reserved = c.fetchone() or (0,0)
                quotas.append(dict(feature=feature,included=terms.included_units,used=used,reserved=reserved,
                                   remaining=max(0,terms.included_units-used-reserved),credits_per_unit=terms.credits_per_unit))
            return dict(cohort=contract['cohort'],channel=actor['channel'],plan=contract['plan'],
                        policy_version=policy.version,balance=balance,reserved=held,available=balance-held,
                        period_start=start.isoformat(),period_end=end.isoformat(),quotas=quotas,
                        products=[dict(code=k,price_idr=v.price_idr,credits=v.credits) for k,v in policy.topups.items()],
                        checkout_available=False)
        return self._run(identity_id,action)

    def history(self, identity_id, *, before=None, limit=25):
        if type(limit) is not int or not 1 <= limit <= 50: raise ValueError('Invalid limit')
        if before is not None: identifier(before,'cursor')
        def action(c,actor,now):
            # No provider result, transaction description, auth or raw metadata exposed.
            bound=''; params=[actor['id']]
            if before:
                c.execute('SELECT created_at,id FROM core_usage_operations WHERE id=%s AND identity_id=%s',(before,actor['id']))
                previous=c.fetchone()
                if not previous: raise CoreError(ErrorCode.FEATURE_NOT_ALLOWED)
                bound=' AND (created_at,id)<(%s,%s)'; params.extend(previous)
            c.execute('SELECT id,feature,state,funding,credits,created_at,settled_at FROM core_usage_operations WHERE identity_id=%s'+bound+
                      ' ORDER BY created_at DESC,id DESC LIMIT %s',(*params,limit+1))
            rows=c.fetchall(); names=[d[0] for d in c.description]
            items=[{k:(v.isoformat() if hasattr(v,'isoformat') else v) for k,v in zip(names,r)} for r in rows[:limit]]
            return dict(items=items,next_cursor=items[-1]['id'] if len(rows)>limit else None)
        return self._run(identity_id,action)

    def credits(self, identity_id, *, before=None, limit=25):
        if type(limit) is not int or not 1 <= limit <= 50: raise ValueError('Invalid limit')
        if before is not None and (type(before) is not int or before<=0): raise ValueError('Invalid cursor')
        def action(c,actor,now):
            accounts=self._wallet_accounts(c,actor['account_id'])
            c.execute('SELECT id,kind,amount,created_at FROM core_credit_entries WHERE account_id=ANY(%s) AND (%s IS NULL OR id<%s) ORDER BY id DESC LIMIT %s',
                      (accounts,before,before,limit+1))
            rows=c.fetchall()
            items=[dict(id=r[0],kind=r[1],amount=r[2],created_at=r[3].isoformat()) for r in rows[:limit]]
            return dict(items=items,next_cursor=items[-1]['id'] if len(rows)>limit else None)
        return self._run(identity_id,action)

    def orders(self,identity_id):
        def action(c,actor,now):
            c.execute('SELECT * FROM core_topup_orders WHERE identity_id=%s ORDER BY created_at DESC,id DESC LIMIT 50',(actor['id'],))
            rows=[]
            while (value:=_row(c)) is not None: rows.append(public_order(value))
            return rows
        return self._run(identity_id,action)

    def order(self,identity_id,product_code,request_key,*,product_reference):
        identifier(request_key,'idempotency_key')
        if not isinstance(product_reference,str) or not 1 <= len(product_reference) <= 256:
            raise PaymentError('provider_product_unavailable')
        def action(c,actor,now):
            c.execute('SELECT * FROM core_topup_orders WHERE identity_id=%s AND request_key=%s',(actor['id'],request_key))
            old=_row(c)
            if old:
                if old['product_code']!=product_code: raise CoreError(ErrorCode.IDEMPOTENCY_CONFLICT)
                return public_order(old)
            contract,policy=self._contract(c,actor,now)
            topup=policy.topup(product_code)
            # One pending snapshot per identity/product, even with a new browser key.
            c.execute("SELECT * FROM core_topup_orders WHERE identity_id=%s AND product_code=%s AND status='pending' ORDER BY created_at,id LIMIT 1",
                      (actor['id'],product_code))
            if _row(c) is not None: raise CoreError(ErrorCode.OPERATION_IN_PROGRESS)
            c.execute('''INSERT INTO core_topup_orders
                (id,identity_id,account_id,request_key,product_code,policy_version,price_idr,credits,provider,product_reference,created_at)
                VALUES (%s,%s,%s,%s,%s,%s,%s,%s,'lynk',%s,%s) RETURNING *''',
                ('DTC-'+uuid4().hex,actor['id'],actor['account_id'],request_key,product_code,policy.version,
                 topup.price_idr,topup.credits,product_reference,now))
            return public_order(_row(c))
        return self._run(identity_id,action)

    def settle(self,payment):
        if not isinstance(payment,VerifiedPayment): raise PaymentError('verified_payment_required')
        with closing(self.connect()) as conn:
            with conn.cursor() as c:
                c.execute('SELECT identity_id FROM core_topup_orders WHERE id=%s',(payment.order_id,))
                owner=c.fetchone()
                if not owner: raise PaymentError('order_not_found')
        def action(c,actor,now):
            c.execute('SELECT * FROM core_topup_orders WHERE id=%s AND identity_id=%s FOR UPDATE',(payment.order_id,actor['id']))
            order=_row(c)
            if (not order or not self._same_wallet(c,order['account_id'],actor['account_id']) or order['provider']!=payment.provider or
                    order['product_reference']!=payment.product_reference or order['price_idr']!=payment.paid_idr):
                raise PaymentError('payment_order_mismatch')
            source='lynk_'+hashlib.sha256(payment.provider_reference.encode()).hexdigest()
            receipt=VerifiedTopUp(source,order['id'],order['policy_version'],order['product_code'],payment.paid_idr,payment.evidence_reference)
            entry=self._credit_topup(c,actor,now,receipt)
            if order['status']=='paid':
                if order['ledger_id']!=entry: raise CoreError(ErrorCode.IDEMPOTENCY_CONFLICT)
                return public_order(order)
            c.execute("UPDATE core_topup_orders SET status='paid',ledger_id=%s,paid_at=%s WHERE id=%s RETURNING *",(entry,now,order['id']))
            return public_order(_row(c))
        return self._run(owner[0],action)
