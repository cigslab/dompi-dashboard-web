"""Explicit two-channel consent. Callers supply identities authenticated by adapters.

No phone-number matching, grant conversion, transaction sharing or unlink/relink.
Wallet merging requires quiescent accounts and preserves all old ledger entries.
"""
from contextlib import closing
from datetime import timedelta
import hashlib
from uuid import uuid4
from .postgres import PostgresUsage,_row
from ..errors import CoreError,ErrorCode
from ..usage import identifier


class Linking(PostgresUsage):
    def identity(self,channel,subject):
        if channel not in ('telegram','whatsapp') or not isinstance(subject,str): raise ValueError('Verified subject required')
        with closing(self.connect()) as conn:
            with conn.cursor() as c:
                c.execute('SELECT id FROM core_identities WHERE channel=%s AND external_subject=%s',(channel,subject))
                found=c.fetchone()
                if not found: raise CoreError(ErrorCode.FEATURE_NOT_ALLOWED)
                return found[0]

    def start(self,identity):
        import secrets
        token=secrets.token_hex(32);key=uuid4().hex
        def action(c,actor,now):
            if actor['channel']!='telegram': raise CoreError(ErrorCode.FEATURE_NOT_ALLOWED)
            c.execute('SELECT COUNT(*) FROM core_identities WHERE account_id=%s',(actor['account_id'],))
            if c.fetchone()[0]!=1: raise CoreError(ErrorCode.FEATURE_NOT_ALLOWED)
            c.execute('SELECT COUNT(*) FROM core_link_requests WHERE telegram_identity=%s AND created_at>%s',(identity,now-timedelta(hours=1)))
            if c.fetchone()[0]>=5: raise CoreError(ErrorCode.TEMPORARILY_UNAVAILABLE)
            c.execute("UPDATE core_link_requests SET state='cancelled' WHERE telegram_identity=%s AND state IN ('pending','claimed')",(identity,))
            c.execute("INSERT INTO core_link_requests VALUES(%s,%s,%s,NULL,'pending',%s,%s)",
                      (key,hashlib.sha256(token.encode()).hexdigest(),identity,now,now+timedelta(minutes=10)))
            return dict(id=key,code=token,expires_at=(now+timedelta(minutes=10)).isoformat())
        return self._run(identity,action)

    def claim(self,identity,token):
        if not isinstance(token,str) or len(token)!=64: raise CoreError(ErrorCode.FEATURE_NOT_ALLOWED)
        digest=hashlib.sha256(token.encode()).hexdigest()
        def action(c,actor,now):
            if actor['channel']!='whatsapp': raise CoreError(ErrorCode.FEATURE_NOT_ALLOWED)
            c.execute('SELECT COUNT(*) FROM core_link_attempts WHERE identity_id=%s AND created_at>%s',(identity,now-timedelta(minutes=10)))
            if c.fetchone()[0]>=5: return CoreError(ErrorCode.TEMPORARILY_UNAVAILABLE)
            c.execute('INSERT INTO core_link_attempts VALUES(%s,%s)',(identity,now))
            c.execute('SELECT * FROM core_link_requests WHERE token_hash=%s FOR UPDATE',(digest,));request=_row(c)
            if (not request or now>=request['expires_at'] or request['state'] not in ('pending','claimed') or
                    request['whatsapp_identity'] not in (None,identity)):
                return CoreError(ErrorCode.FEATURE_NOT_ALLOWED)
            c.execute('SELECT COUNT(*) FROM core_identities WHERE account_id=%s',(actor['account_id'],))
            if c.fetchone()[0]!=1: return CoreError(ErrorCode.FEATURE_NOT_ALLOWED)
            c.execute("UPDATE core_link_requests SET whatsapp_identity=%s,state='claimed' WHERE id=%s",(identity,request['id']))
            return dict(id=request['id'],state='claimed')
        result=self._run(identity,action)
        if isinstance(result,CoreError): raise result
        return result

    def inspect(self,identity,key):
        identifier(key,'link_request')
        def action(c,actor,now):
            c.execute('SELECT * FROM core_link_requests WHERE id=%s AND telegram_identity=%s',(key,identity));r=_row(c)
            if not r or (now>=r['expires_at'] and r['state']!='linked'): raise CoreError(ErrorCode.FEATURE_NOT_ALLOWED)
            if r['whatsapp_identity'] is None: return dict(id=key,state=r['state'])
            c.execute('SELECT external_subject FROM core_identities WHERE id=%s',(r['whatsapp_identity'],))
            return dict(id=key,state=r['state'],whatsapp_subject=c.fetchone()[0],claim=r['whatsapp_identity'])
        return self._run(identity,action)

    def cancel(self,identity,key):
        def action(c,actor,now):
            c.execute("UPDATE core_link_requests SET state='cancelled' WHERE id=%s AND telegram_identity=%s AND state IN ('pending','claimed')",(key,identity))
        return self._run(identity,action)

    def confirm(self,identity,key,expected_whatsapp):
        """Final Telegram consent binds the exact WhatsApp identity shown to it."""
        for value in (identity,key,expected_whatsapp): identifier(value,'identity_or_request')
        for attempt in range(3):
            with closing(self.connect()) as conn:
                try:
                    conn.set_session(isolation_level='READ COMMITTED',autocommit=False)
                    with conn.cursor() as c:
                        c.execute('SELECT * FROM core_identities WHERE id IN (%s,%s) ORDER BY id',(identity,expected_whatsapp))
                        rows={r['id']:r for r in iter(lambda:_row(c),None)}
                        if (len(rows)!=2 or rows[identity]['channel']!='telegram' or rows[expected_whatsapp]['channel']!='whatsapp'):
                            raise CoreError(ErrorCode.FEATURE_NOT_ALLOWED)
                        target=rows[identity]['account_id'];source=rows[expected_whatsapp]['account_id']
                        accounts=sorted({source,target})
                        c.execute('SELECT id FROM core_accounts WHERE id=ANY(%s) ORDER BY id FOR UPDATE',(accounts,))
                        c.execute('SELECT * FROM core_wallets WHERE account_id=ANY(%s) ORDER BY account_id FOR UPDATE',(accounts,))
                        wallets={r['account_id']:r for r in iter(lambda:_row(c),None)}
                        c.execute('SELECT id,account_id FROM core_identities WHERE id IN (%s,%s) ORDER BY id FOR UPDATE',(identity,expected_whatsapp))
                        if any(rows[i]['account_id']!=a for i,a in c.fetchall()): raise CoreError(ErrorCode.TEMPORARILY_UNAVAILABLE)
                        now=self._now(c)
                        c.execute('SELECT * FROM core_link_requests WHERE id=%s FOR UPDATE',(key,));request=_row(c)
                        if not request or request['telegram_identity']!=identity or request['whatsapp_identity']!=expected_whatsapp:
                            raise CoreError(ErrorCode.FEATURE_NOT_ALLOWED)
                        if request['state']=='linked':
                            conn.commit();return dict(state='linked',account_id=target)
                        if request['state']!='claimed' or now>=request['expires_at'] or source==target:
                            raise CoreError(ErrorCode.FEATURE_NOT_ALLOWED)
                        c.execute('SELECT COUNT(*) FROM core_identities WHERE account_id=ANY(%s)',(accounts,))
                        if c.fetchone()[0]!=2: raise CoreError(ErrorCode.FEATURE_NOT_ALLOWED)
                        c.execute('SELECT 1 FROM core_wallet_merges WHERE source_account=ANY(%s) OR target_account=ANY(%s)',(accounts,accounts))
                        if c.fetchone(): raise CoreError(ErrorCode.FEATURE_NOT_ALLOWED)
                        c.execute("SELECT 1 FROM core_usage_operations WHERE account_id=ANY(%s) AND state IN ('reserved','executing','uncertain') LIMIT 1",(accounts,))
                        if c.fetchone() or any(w['reserved'] for w in wallets.values()): raise CoreError(ErrorCode.OPERATION_IN_PROGRESS)
                        c.execute("SELECT 1 FROM core_topup_orders WHERE account_id=ANY(%s) AND status='pending' LIMIT 1",(accounts,))
                        if c.fetchone(): raise CoreError(ErrorCode.OPERATION_IN_PROGRESS)
                        amount=wallets[source]['balance']
                        c.execute('INSERT INTO core_wallet_merges VALUES(%s,%s,%s,%s,%s,%s,%s)',(source,target,key,identity,expected_whatsapp,amount,now))
                        c.execute('UPDATE core_wallets SET balance=0 WHERE account_id=%s',(source,))
                        c.execute('UPDATE core_wallets SET balance=balance+%s WHERE account_id=%s',(amount,target))
                        c.execute('UPDATE core_identities SET account_id=%s WHERE id=%s',(target,expected_whatsapp))
                        c.execute("UPDATE core_link_requests SET state='linked' WHERE id=%s",(key,))
                    conn.commit();return dict(state='linked',account_id=target)
                except BaseException as error:
                    conn.rollback()
                    if getattr(error,'pgcode',None) in ('40001','40P01') and attempt<2: continue
                    raise
