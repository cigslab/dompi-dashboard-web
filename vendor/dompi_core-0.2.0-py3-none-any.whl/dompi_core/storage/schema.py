"""Explicit additive PostgreSQL migration. Caller owns commit/rollback.

No legacy tables are inspected or changed. Identity/contract provisioning and
account linking are separate trusted workflows, not implicit backfills.
"""
import hashlib
import json

from ..policies import POLICIES

VERSION = 'core_usage_v2_001'
DDL = '''
CREATE TABLE core_accounts (id TEXT PRIMARY KEY);
CREATE TABLE core_wallets (
 account_id TEXT PRIMARY KEY REFERENCES core_accounts(id),
 balance BIGINT NOT NULL DEFAULT 0 CHECK (balance >= 0),
 reserved BIGINT NOT NULL DEFAULT 0 CHECK (reserved >= 0 AND reserved <= balance));
CREATE TABLE core_identities (
 id TEXT PRIMARY KEY, account_id TEXT NOT NULL REFERENCES core_accounts(id),
 channel TEXT NOT NULL CHECK (channel IN ('telegram','whatsapp')),
 external_subject TEXT NOT NULL, UNIQUE(channel, external_subject));
CREATE TABLE core_policies (
 version TEXT PRIMARY KEY, content_hash TEXT NOT NULL, snapshot JSONB NOT NULL);
CREATE TABLE core_channel_contracts (
 id TEXT PRIMARY KEY, identity_id TEXT NOT NULL REFERENCES core_identities(id),
 cohort TEXT NOT NULL CHECK (cohort IN ('legacy','v2_purchase','v2_opt_in')),
 plan TEXT CHECK (plan IN ('starter','pro')),
 policy_version TEXT REFERENCES core_policies(version),
 requires_review BOOLEAN NOT NULL DEFAULT FALSE,
 evidence_reference TEXT,
 starts_at TIMESTAMPTZ NOT NULL, ends_at TIMESTAMPTZ,
 CHECK (ends_at IS NULL OR ends_at > starts_at),
 CHECK (cohort = 'legacy' OR (plan IS NOT NULL AND policy_version IS NOT NULL
         AND evidence_reference IS NOT NULL AND length(evidence_reference) > 0)));
CREATE UNIQUE INDEX core_one_current_contract ON core_channel_contracts(identity_id) WHERE ends_at IS NULL;
CREATE TABLE core_quota_buckets (
 id BIGSERIAL PRIMARY KEY, identity_id TEXT NOT NULL REFERENCES core_identities(id),
 feature TEXT NOT NULL, period_start TIMESTAMPTZ NOT NULL, period_end TIMESTAMPTZ NOT NULL,
 committed BIGINT NOT NULL DEFAULT 0 CHECK (committed >= 0),
 reserved BIGINT NOT NULL DEFAULT 0 CHECK (reserved >= 0),
 CHECK (period_end > period_start), UNIQUE(identity_id, feature, period_start));
CREATE TABLE core_usage_batches (
 id TEXT PRIMARY KEY, identity_id TEXT NOT NULL REFERENCES core_identities(id),
 event_key TEXT NOT NULL, request_fingerprint TEXT NOT NULL,
 UNIQUE(identity_id, event_key));
CREATE TABLE core_usage_operations (
 id TEXT PRIMARY KEY, batch_id TEXT NOT NULL REFERENCES core_usage_batches(id),
 child_index INTEGER NOT NULL CHECK (child_index >= 0),
 identity_id TEXT NOT NULL REFERENCES core_identities(id),
 account_id TEXT NOT NULL REFERENCES core_wallets(account_id),
 feature TEXT NOT NULL, request_fingerprint TEXT NOT NULL,
 policy_version TEXT NOT NULL REFERENCES core_policies(version), policy_snapshot JSONB NOT NULL,
 bucket_id BIGINT NOT NULL REFERENCES core_quota_buckets(id),
 funding TEXT NOT NULL CHECK (funding IN ('quota','credit')),
 credits BIGINT NOT NULL CHECK (credits >= 0),
 CHECK ((funding = 'quota' AND credits = 0) OR (funding = 'credit' AND credits > 0)),
 state TEXT NOT NULL CHECK (state IN ('reserved','executing','uncertain','committed','released','reversed')),
 reserve_until TIMESTAMPTZ NOT NULL, execute_until TIMESTAMPTZ, recover_after TIMESTAMPTZ,
 execution_token TEXT, result JSONB, result_fingerprint TEXT, reason TEXT,
 created_at TIMESTAMPTZ NOT NULL, settled_at TIMESTAMPTZ,
 CHECK (state NOT IN ('executing','uncertain','committed','reversed') OR
        (execution_token IS NOT NULL AND execute_until IS NOT NULL AND recover_after IS NOT NULL)),
 CHECK (state NOT IN ('committed','reversed') OR (result IS NOT NULL AND result_fingerprint IS NOT NULL)),
 UNIQUE(batch_id, child_index));
CREATE INDEX core_usage_recovery ON core_usage_operations(state, reserve_until, recover_after);
CREATE TABLE core_credit_entries (
 id BIGSERIAL PRIMARY KEY, account_id TEXT NOT NULL REFERENCES core_wallets(account_id),
 kind TEXT NOT NULL CHECK (kind IN ('topup','debit','refund')),
 amount BIGINT NOT NULL,
 operation_id TEXT REFERENCES core_usage_operations(id),
 source_key TEXT UNIQUE, order_id TEXT UNIQUE,
 metadata JSONB NOT NULL, created_at TIMESTAMPTZ NOT NULL,
 CHECK ((kind = 'debit' AND amount < 0 AND operation_id IS NOT NULL AND source_key IS NULL AND order_id IS NULL)
     OR (kind = 'refund' AND amount > 0 AND operation_id IS NOT NULL AND source_key IS NULL AND order_id IS NULL)
     OR (kind = 'topup' AND amount > 0 AND operation_id IS NULL AND source_key IS NOT NULL AND order_id IS NOT NULL)),
 UNIQUE(operation_id, kind));
CREATE FUNCTION core_reject_mutation() RETURNS trigger LANGUAGE plpgsql AS $$
 BEGIN RAISE EXCEPTION 'Immutable Core history'; END $$;
CREATE TRIGGER core_ledger_immutable BEFORE UPDATE OR DELETE ON core_credit_entries
 FOR EACH ROW EXECUTE FUNCTION core_reject_mutation();
CREATE TRIGGER core_ledger_no_truncate BEFORE TRUNCATE ON core_credit_entries
 FOR EACH STATEMENT EXECUTE FUNCTION core_reject_mutation();
CREATE TRIGGER core_policy_immutable BEFORE UPDATE OR DELETE ON core_policies
 FOR EACH ROW EXECUTE FUNCTION core_reject_mutation();
CREATE TRIGGER core_policy_no_truncate BEFORE TRUNCATE ON core_policies
 FOR EACH STATEMENT EXECUTE FUNCTION core_reject_mutation();
'''


def migrate(connection):
    if connection.autocommit:
        raise ValueError('Migration requires caller-owned transaction')
    with connection.cursor() as c:
        c.execute('SAVEPOINT core_usage_migration')
        try:
            # Only migration uses a global lock; live account traffic never does.
            c.execute("SELECT pg_advisory_xact_lock(193003, 2)")
            c.execute('CREATE TABLE IF NOT EXISTS core_migrations (version TEXT PRIMARY KEY, ddl_hash TEXT NOT NULL)')
            c.execute('SELECT ddl_hash FROM core_migrations WHERE version=%s', (VERSION,))
            row = c.fetchone()
            digest = hashlib.sha256(DDL.encode()).hexdigest()
            if row is not None and row[0] != digest:
                raise ValueError('Migration fingerprint mismatch')
            if row is None:
                c.execute(DDL)
                c.execute('INSERT INTO core_migrations VALUES (%s,%s)', (VERSION, digest))
            for policy in POLICIES.values():
                c.execute('INSERT INTO core_policies VALUES (%s,%s,%s::jsonb) ON CONFLICT DO NOTHING',
                          (policy.version, policy.content_hash, json.dumps(policy.snapshot())))
                c.execute('SELECT content_hash, snapshot FROM core_policies WHERE version=%s', (policy.version,))
                if c.fetchone() != (policy.content_hash, policy.snapshot()):
                    raise ValueError('Stored policy differs from registered immutable policy')
            c.execute('RELEASE SAVEPOINT core_usage_migration')
            return row is None
        except BaseException:
            c.execute('ROLLBACK TO SAVEPOINT core_usage_migration')
            c.execute('RELEASE SAVEPOINT core_usage_migration')
            raise
