"""Pure compatibility entitlement rules; explicit clock and policy, no runtime I/O."""
from dataclasses import dataclass
from datetime import datetime

CONTRACT_VERSION = '1'

@dataclass(frozen=True)
class Entitlement:
    effective: str | None
    lifetime: str | None
    legacy_status: str
    legacy_expires_at: datetime | None
    requires_review: bool
    contract_version: str = CONTRACT_VERSION

@dataclass(frozen=True)
class Capabilities:
    manual_recording: bool
    receipt: bool
    export: bool
    advanced_analytics: bool
    monthly_limit: int | None

    def __post_init__(self):
        for value in (self.manual_recording, self.receipt, self.export, self.advanced_analytics):
            if type(value) is not bool:
                raise ValueError('Capabilities must be explicit booleans')
        if self.monthly_limit is not None and (type(self.monthly_limit) is not int or self.monthly_limit < 0):
            raise ValueError('monthly_limit must be a nonnegative integer or None')


def _legacy(plan, expiry, now):
    if plan in (None, 'free'):
        return ('none', None) if expiry in (None, '') else ('ambiguous', None)
    if plan != 'pro':
        return 'ambiguous', None
    if not isinstance(expiry, str) or not expiry:
        return 'ambiguous', None
    parsed = None
    for fmt in ('%Y-%m-%d %H:%M:%S', '%Y-%m-%d'):
        try:
            candidate = datetime.strptime(expiry, fmt)
            if candidate.strftime(fmt) == expiry:
                parsed = candidate
                break
        except ValueError:
            pass
    if parsed is None:
        return 'ambiguous', None
    return ('active' if now < parsed else 'expired'), parsed


def resolve_entitlement(*, lifetime=None, legacy_plan=None, pro_until=None, now):
    """Resolve explicit lifetime and independent legacy timed grant.

    lifetime is None/'starter'/'pro'. effective=None means unresolved, not Free.
    A proven lifetime grant remains the minimum entitlement even if legacy data
    is ambiguous; requires_review instructs callers not to assume absence of Pro.
    """
    if lifetime not in (None, 'starter', 'pro'):
        raise ValueError('Unknown lifetime entitlement')
    if not isinstance(now, datetime) or now.tzinfo is not None:
        raise ValueError('now must be explicit naive server-local datetime')
    status, expiry = _legacy(legacy_plan, pro_until, now)
    if lifetime == 'pro':
        effective = 'pro_lifetime'
    elif status == 'active':
        effective = 'pro_legacy_active'
    elif lifetime == 'starter':
        effective = 'starter_lifetime'
    elif status == 'ambiguous':
        effective = None
    else:
        effective = 'free'
    return Entitlement(effective, lifetime, status, expiry, status == 'ambiguous')


def resolve_capabilities(entitlement, *, free_policy):
    """Never infer Free policy or downgrade an ambiguous legacy entitlement.

    free_policy must describe existing deployed behavior; this module deliberately
    does not import config.py or assign new Free export/analytics restrictions.
    """
    if not isinstance(free_policy, Capabilities):
        raise ValueError('Explicit Free compatibility policy required')
    if entitlement.effective == 'pro_lifetime':
        return Capabilities(True, True, True, True, None)
    if entitlement.requires_review or entitlement.effective is None:
        raise ValueError('Legacy entitlement requires reconciliation')
    if entitlement.effective == 'pro_legacy_active':
        return Capabilities(True, True, True, True, None)
    if entitlement.effective == 'starter_lifetime':
        return Capabilities(True, False, False, False, 150)
    if entitlement.effective == 'free':
        return free_policy
    raise ValueError('Unknown effective entitlement')


def has_paid_access(entitlement: Entitlement | None) -> bool:
    """Entry access only; feature-specific review and quota policies remain separate."""
    return entitlement is not None and (
        entitlement.lifetime in ('starter', 'pro') or
        entitlement.effective == 'pro_legacy_active')
