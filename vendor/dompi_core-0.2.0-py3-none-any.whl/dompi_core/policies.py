"""Explicit immutable v2 terms, not entitlement enforcement or a credit ledger."""
from dataclasses import dataclass
import hashlib
import json
from types import MappingProxyType
from typing import Mapping

from .errors import CoreError, ErrorCode
from .features import FEATURES, FeatureRegistry


def _integer(value, name, minimum=0):
    if type(value) is not int or value < minimum:
        raise ValueError(f'{name} must be an integer >= {minimum}')


@dataclass(frozen=True)
class UsageTerms:
    included_units: int | None
    credits_per_unit: int

    def __post_init__(self):
        if self.included_units is not None:
            _integer(self.included_units, 'included_units')
        _integer(self.credits_per_unit, 'credits_per_unit')


@dataclass(frozen=True)
class PackagePolicy:
    lifetime_price_idr: int
    usage: Mapping[str, UsageTerms]

    def __post_init__(self):
        _integer(self.lifetime_price_idr, 'lifetime_price_idr', 1)
        copied = dict(self.usage)
        if any(not isinstance(k, str) or not isinstance(v, UsageTerms) for k, v in copied.items()):
            raise ValueError('Explicit feature usage terms required')
        object.__setattr__(self, 'usage', MappingProxyType(copied))


@dataclass(frozen=True)
class TopUp:
    price_idr: int
    credits: int

    def __post_init__(self):
        _integer(self.price_idr, 'price_idr', 1)
        _integer(self.credits, 'credits', 1)


@dataclass(frozen=True)
class PricingPolicy:
    version: str
    features: FeatureRegistry
    packages: Mapping[tuple[str, str], PackagePolicy]
    topups: Mapping[str, TopUp]
    period_timezone: str = 'Asia/Jakarta'
    currency: str = 'IDR'
    topup_expires: bool = False

    def __post_init__(self):
        if not isinstance(self.version, str) or not self.version.strip():
            raise ValueError('Explicit policy version required')
        if not isinstance(self.features, FeatureRegistry):
            raise ValueError('Explicit feature registry required')
        if self.period_timezone != 'Asia/Jakarta' or self.currency != 'IDR' or self.topup_expires is not False:
            raise ValueError('Unsupported period, currency or top-up expiry policy')
        packages, topups = dict(self.packages), dict(self.topups)
        if not packages or not topups:
            raise ValueError('Packages and top-ups required')
        for key, package in packages.items():
            if (not isinstance(key, tuple) or len(key) != 2 or
                    key[0] not in ('telegram', 'whatsapp') or key[1] not in ('starter', 'pro') or
                    not isinstance(package, PackagePolicy)):
                raise ValueError('Invalid channel/package policy')
            for code, terms in package.usage.items():
                feature = self.features.get(code)
                if feature.uses_ai:
                    if terms.included_units is None or terms.credits_per_unit < 1:
                        raise ValueError('AI requires finite quota and positive credit rate')
                elif terms != UsageTerms(None, 0):
                    raise ValueError('Non-AI usage must consume neither quota nor credits')
        if any(not isinstance(k, str) or not k or not isinstance(v, TopUp) for k, v in topups.items()):
            raise ValueError('Invalid top-up catalog')
        object.__setattr__(self, 'packages', MappingProxyType(packages))
        object.__setattr__(self, 'topups', MappingProxyType(topups))

    def package(self, *, channel: str, plan: str) -> PackagePolicy:
        try:
            return self.packages[channel, plan]
        except (KeyError, TypeError):
            raise CoreError(ErrorCode.POLICY_MISSING) from None

    def terms(self, *, channel: str, plan: str, feature: str) -> UsageTerms:
        self.features.get(feature)
        package = self.package(channel=channel, plan=plan)
        try:
            return package.usage[feature]
        except (KeyError, TypeError):
            raise CoreError(ErrorCode.POLICY_MISSING) from None

    def topup(self, code: str) -> TopUp:
        try:
            return self.topups[code]
        except (KeyError, TypeError):
            raise CoreError(ErrorCode.POLICY_MISSING) from None

    def snapshot(self) -> dict:
        """Detached, JSON-compatible terms; never references mutable source maps."""
        return {
            'schema_version': 1, 'version': self.version, 'currency': self.currency,
            'period_timezone': self.period_timezone, 'topup_expires': self.topup_expires,
            'features': {k: {'unit': f.unit, 'capability': f.capability,
                             'uses_ai': f.uses_ai, 'success_contract': f.success_contract}
                         for k, f in sorted(self.features.features.items())},
            'packages': [
                {'channel': channel, 'plan': plan, 'lifetime_price_idr': p.lifetime_price_idr,
                 'usage': {k: {'included_units': t.included_units, 'credits_per_unit': t.credits_per_unit}
                           for k, t in sorted(p.usage.items())}}
                for (channel, plan), p in sorted(self.packages.items())],
            'topups': {k: {'price_idr': t.price_idr, 'credits': t.credits}
                       for k, t in sorted(self.topups.items())},
        }

    @property
    def content_hash(self) -> str:
        encoded = json.dumps(self.snapshot(), sort_keys=True, separators=(',', ':'), allow_nan=False)
        return hashlib.sha256(encoded.encode('utf-8')).hexdigest()


def _package(price, text, receipt, text_rate, receipt_rate):
    return PackagePolicy(price, {'ai_text': UsageTerms(text, text_rate),
                                'receipt': UsageTerms(receipt, receipt_rate),
                                'manual_recording': UsageTerms(None, 0)})


BASELINE_V2 = PricingPolicy(
    version='2.0.0', features=FEATURES,
    packages={
        ('telegram', 'starter'): _package(49000, 100, 15, 1, 5),
        ('telegram', 'pro'): _package(99000, 300, 50, 1, 5),
        ('whatsapp', 'starter'): _package(99000, 75, 10, 2, 7),
        ('whatsapp', 'pro'): _package(199000, 200, 30, 2, 7),
    },
    topups={'topup_100': TopUp(10000, 100), 'topup_220': TopUp(20000, 220),
            'topup_350': TopUp(30000, 350)},
)

POLICIES = MappingProxyType({BASELINE_V2.version: BASELINE_V2})


def get_policy(*, version: str, cohort: str) -> PricingPolicy:
    """No latest-policy default and no automatic legacy migration.

    Cohort must come from a trusted stored contract, never a client request.
    Consent persistence and entitlement checks belong to later slices.
    """
    if cohort == 'legacy':
        raise CoreError(ErrorCode.LEGACY_POLICY_REQUIRED)
    if cohort not in ('v2_purchase', 'v2_opt_in'):
        raise CoreError(ErrorCode.FEATURE_NOT_ALLOWED)
    try:
        return POLICIES[version]
    except (KeyError, TypeError):
        raise CoreError(ErrorCode.POLICY_NOT_FOUND) from None
