"""Immutable feature metadata; registration never invokes an executor."""
from dataclasses import dataclass
import re
from types import MappingProxyType
from typing import Mapping

from .errors import CoreError, ErrorCode


@dataclass(frozen=True)
class Feature:
    code: str
    unit: str
    capability: str
    uses_ai: bool
    success_contract: str

    def __post_init__(self):
        for value in (self.code, self.unit, self.capability, self.success_contract):
            if not isinstance(value, str) or not re.fullmatch(r'[a-z][a-z0-9_]*', value):
                raise ValueError('Feature fields must be stable identifiers')
        if type(self.uses_ai) is not bool:
            raise ValueError('uses_ai must be an explicit boolean')


@dataclass(frozen=True)
class FeatureRegistry:
    features: Mapping[str, Feature]

    def __post_init__(self):
        copied = dict(self.features)
        if not copied or any(not isinstance(v, Feature) or k != v.code for k, v in copied.items()):
            raise ValueError('Registry keys must match feature codes')
        object.__setattr__(self, 'features', MappingProxyType(copied))

    def get(self, code: str) -> Feature:
        try:
            return self.features[code]
        except (KeyError, TypeError):
            raise CoreError(ErrorCode.UNKNOWN_FEATURE) from None


FEATURES = FeatureRegistry({f.code: f for f in (
    Feature('ai_text', 'transaction', 'manual_recording', True,
            'valid_ai_result_durable'),
    Feature('receipt', 'receipt', 'receipt', True,
            'complete_valid_ai_result_ready'),
    Feature('manual_recording', 'transaction', 'manual_recording', False,
            'no_provider_execution'),
)})
