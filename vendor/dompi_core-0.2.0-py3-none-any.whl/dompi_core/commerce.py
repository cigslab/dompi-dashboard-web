"""Trusted payment evidence, independent from HTTP and provider configuration."""
from dataclasses import dataclass
from .usage import identifier


class PaymentError(ValueError):
    def __init__(self, code):
        self.code = code
        super().__init__(code)


@dataclass(frozen=True)
class VerifiedPayment:
    """Internal verifier result. Never deserialize this from an HTTP client."""
    order_id: str
    provider_reference: str
    product_reference: str
    paid_idr: int
    evidence_reference: str
    provider: str = 'lynk'

    def __post_init__(self):
        for field in ('order_id','provider_reference','evidence_reference'):
            identifier(getattr(self, field), field)
        if (self.provider != 'lynk' or type(self.paid_idr) is not int or self.paid_idr <= 0
                or not isinstance(self.product_reference,str) or not 1 <= len(self.product_reference) <= 256):
            raise PaymentError('invalid_payment_evidence')
